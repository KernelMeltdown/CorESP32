This example is based on [wreyford's](https://github.com/wreyford/demo_esp_littlefs) demo project.

Modifications were made so that this example project could be built as a part of CI.
