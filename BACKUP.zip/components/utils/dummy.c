// Placeholder - utils will be added later
void utils_dummy(void) {
    // Empty
}