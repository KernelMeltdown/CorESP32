// Placeholder - bootloader will be added later
void bootloader_dummy(void) {
    // Empty
}