CorESP32 - Phase 1 foundation files (1-6) created.
Run 'idf.py set-target esp32c6' and then 'idf.py build' on your machine with ESP-IDF installed.
